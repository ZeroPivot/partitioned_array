# create a partitioned array function
# input: array, number of partitions
# output: array of arrays
# example: generate_ai([1,2,3,4,5,6,7,8,9,10], 3) => [[1,2,3,4,5], [6,7,8], [9,10]]
def generate_ai(array, partitions)
  # generate code here:

end

# Path: partitioned_array\test_ai.rb
# test the generate_ai function
require_relative 'generate_ai'
