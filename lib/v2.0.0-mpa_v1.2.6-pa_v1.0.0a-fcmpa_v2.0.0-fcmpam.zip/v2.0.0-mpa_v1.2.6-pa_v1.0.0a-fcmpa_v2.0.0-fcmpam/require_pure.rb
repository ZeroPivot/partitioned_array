require 'pure_managed_partitioned_array' 

# requires the partitioned array with no json requirements (pure)