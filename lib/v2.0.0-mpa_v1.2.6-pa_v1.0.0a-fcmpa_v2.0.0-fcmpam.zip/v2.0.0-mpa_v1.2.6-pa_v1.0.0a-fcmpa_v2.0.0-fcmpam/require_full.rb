require 'fileutils'
require 'json'
require 'managed_partitioned_array'


# Requires the regular partitioned array with indexing and partitioning (managed)